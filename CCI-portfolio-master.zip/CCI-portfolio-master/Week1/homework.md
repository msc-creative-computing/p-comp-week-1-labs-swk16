# Background
SANity (Sanity) is the player value of the Cthulhu Mythology table game. To some extent it can be thought of as mental strength. 
For example, if you see something supernatural, or something so horrific that you become mentally stimulated, your SAN will drop, and you will be able to easily win if your enemy uses a psychotic attack.


## In the future, humans go to live on a new planet
With the lack of resources and the dramatic decline in living conditions on the new planet, there are many uncertainties and many people are susceptible to mental disturbances and abnormal behaviour, such as crime.

### That's why the Sanity Detector was created


1. Sound sensors to sense the frequency of noise received by the body or a different sound rate emitted by the body itself(Not included in this project)


2. Heart rate sensors to detect the heart rate of the human body to determine if it is on the verge of a frenzy (Not included in this project)


3. Measuring the temperature of the body (Difference from normal temperature)


4. If the reminder light is illuminated, the person is in a frenzied state

### ***Keep yourself safe by avoiding humans who are in a state of madness, or on the verge of madness***